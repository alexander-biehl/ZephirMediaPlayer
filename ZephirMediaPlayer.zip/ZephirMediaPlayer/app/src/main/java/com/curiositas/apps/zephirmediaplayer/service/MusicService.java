package com.curiositas.apps.zephirmediaplayer.service;

public class MusicService extends MediaBrowserServiceCompat {
}
